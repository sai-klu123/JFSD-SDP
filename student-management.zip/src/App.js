import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { UserProvider } from './context/UserContext'; // Import the UserProvider
import Home from './pages/Home';
import Login from './pages/Login';
import Signup from './pages/Signup';
import Dashboard from './pages/Dashboard';
import AddAch from './pages/AddAch';
import ViewAch from './pages/ViewAch';
import EditAch from './pages/EditAch';

function App() {
  return (
    // Wrap the Router with UserProvider to give all components access to the context
    <UserProvider>
      <Router>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/addach" element={<AddAch />} />
          <Route path="/viewach" element={<ViewAch />} />
                    <Route path="/editach" element={<EditAch />} />

        </Routes>
      </Router>
    </UserProvider>
  );
}

export default App;
