import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faArrowLeft } from '@fortawesome/free-solid-svg-icons';

const AddAch = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const { fullName, email, studentId } = location.state || {};

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    year: '',
    company: '',
    priceMoney: '',
    achievementProof: '',
    fullName: fullName || '',
    email: email || '',
    studentId: studentId || '',
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const endpoint = 'http://localhost:8080/api/achievements';
      const response = await axios.post(endpoint, formData);
      alert(response.data || 'Achievement added successfully!');
      setFormData({
        title: '',
        description: '',
        year: '',
        company: '',
        priceMoney: '',
        achievementProof: '',
        fullName: formData.fullName,
        email: formData.email,
        studentId: formData.studentId,
      });
      navigate('/dashboard');
    } catch (error) {
      console.error('Error:', error.response?.data?.message || error.message);
      alert('Failed to add achievement');
    }
  };

  useEffect(() => {
    if (location.state) {
      setFormData((prevState) => ({
        ...prevState,
        fullName: location.state.fullName,
        email: location.state.email,
        studentId: location.state.studentId,
      }));
    } else {
      setFormData({
        title: '',
        description: '',
        year: '',
        company: '',
        priceMoney: '',
        achievementProof: '',
        fullName: '',
        email: '',
        studentId: '',
      });
    }
  }, [location.state]);

  return (
    <div className="relative flex items-center justify-center min-h-screen bg-cover bg-center" style={{ backgroundImage: "url('/images/bg.jpg')" }}>
      
      {/* Back to Dashboard Button */}
      <button
        onClick={() => navigate('/dashboard')}
        className="absolute top-4 right-4 flex items-center px-6 py-3 bg-blue-600 text-white rounded-lg shadow-lg hover:bg-blue-700 transition"
      >
        <FontAwesomeIcon icon={faArrowLeft} className="mr-2" />
        Back to Dashboard
      </button>

      {/* Form Card */}
      <div className="relative bg-gradient-to-r from-blue-500 to-indigo-600 p-8 rounded-lg shadow-xl max-w-3xl w-full bg-opacity-50 backdrop-blur-sm">
        <div className="text-black mb-6 text-center">
          <p className="font-bold">Hello, <span className="font-extrabold">{formData.fullName}</span>! Add your achievements</p>
        </div>

        <form className="space-y-4" onSubmit={handleSubmit}>
          <div>
            <label className="block text-black">Achievement Title</label>
            <input
              type="text"
              name="title"
              className="w-full border border-gray-300 rounded-md p-3 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              placeholder="Enter achievement title"
              value={formData.title}
              onChange={handleChange}
              required
            />
          </div>

          <div>
            <label className="block text-black">Description</label>
            <textarea
              name="description"
              className="w-full border border-gray-300 rounded-md p-3 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              placeholder="Enter achievement description"
              value={formData.description}
              onChange={handleChange}
              required
            />
          </div>

          <div>
            <label className="block text-black">Year</label>
            <input
              type="text"
              name="year"
              className="w-full border border-gray-300 rounded-md p-3 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              placeholder="Enter year of achievement"
              value={formData.year}
              onChange={handleChange}
              required
            />
          </div>

          <div>
            <label className="block text-black">Company</label>
            <input
              type="text"
              name="company"
              className="w-full border border-gray-300 rounded-md p-3 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              placeholder="Enter the company name"
              value={formData.company}
              onChange={handleChange}
              required
            />
          </div>

          <div>
            <label className="block text-black">Prize Money (if any)</label>
            <input
              type="number"
              name="priceMoney"
              className="w-full border border-gray-300 rounded-md p-3 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              placeholder="Enter prize money"
              value={formData.priceMoney}
              onChange={handleChange}
            />
          </div>

          <div>
            <label className="block text-black">Achievement Proof</label>
            <input
              type="text"
              name="achievementProof"
              className="w-full border border-gray-300 rounded-md p-3 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              placeholder="Enter proof link or description"
              value={formData.achievementProof}
              onChange={handleChange}
            />
            <p className="text-black text-sm mt-1">*If you want to submit it offline, submit it before 24hrs on Cabin number C205.</p>
          </div>

          <button type="submit" className="w-full bg-indigo-600 text-white px-6 py-3 rounded-md hover:bg-indigo-700 transition">
            Add Achievement
          </button>
        </form>
      </div>
    </div>
  );
};

export default AddAch;
