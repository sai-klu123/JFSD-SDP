import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';

const PencilLine = () => {
  const [showLine, setShowLine] = useState(false);
  const pencilLineRef = useRef(null);

  useEffect(() => {
    const pencilLineElement = pencilLineRef.current;

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          setShowLine(true);  // Line is in view
        } else {
          setShowLine(false); // Line is out of view
        }
      });
    }, { threshold: 0.5 });

    if (pencilLineElement) {
      observer.observe(pencilLineElement);
    }

    return () => {
      if (pencilLineElement) {
        observer.unobserve(pencilLineElement);
      }
    };
  }, []);

  return (
    <div
      ref={pencilLineRef}
      className={`pencil-line ${showLine ? 'drawing' : ''}`}
    ></div>
  );
};

const Home = () => {
  const [showButton, setShowButton] = useState(false);

  // Show the button when scrolled down
  const handleScroll = () => {
    if (window.scrollY > 300) {
      setShowButton(true); // Show button after scrolling down 300px
    } else {
      setShowButton(false); // Hide button when at top of the page
    }
  };

  // Scroll the page to the top when the button is clicked
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  useEffect(() => {
    // Add scroll event listener when the component is mounted
    window.addEventListener('scroll', handleScroll);

    // Remove the event listener when the component is unmounted
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);


  return (
    <div className="bg-gradient-to-br from-blue-400 via-indigo-500 to-purple-600 min-h-screen flex flex-col">
      {/* Navigation */}
      <header className="flex justify-between items-center p-6 bg-transparent z-10">
  <h1 className="text-2xl font-bold text-white">Activity Hub</h1>
  <div className="space-x-4">
      <Link to="/login">
        <button className="bg-white text-indigo-500 px-6 py-2 rounded-lg font-semibold hover:bg-indigo-100 transition">
          Login
        </button>
      </Link>
      <Link to="/signup">
        <button className="bg-indigo-600 text-white px-6 py-2 rounded-lg font-semibold hover:bg-indigo-700 transition">
          Signup
        </button>
      </Link>
    </div>
</header>








      {/* Main Content */}
      <main className="flex-grow container mx-auto px-8 py-16 text-white space-y-20">
        {/* Hero Section */}
        <section className="text-center">
          <h1 className="text-4xl md:text-5xl font-extrabold">
            Welcome to Your Activity Hub!
          </h1>
          <p className="text-lg mt-4 font-light">
            Organize, track, and excel in all your extracurricular activities.
          </p>
          <Link to="/signup">
          <button className="mt-6 bg-yellow-500 text-white px-8 py-3 rounded-full text-lg font-semibold hover:bg-yellow-600 transition">
            Get Started
          </button>
          </Link>
        </section>




        {/* About Section */}
        <section className="flex items-center bg-gradient-to-r from-white/20 to-white/10 backdrop-blur-lg rounded-lg p-10 shadow-lg">
          {/* Image Section */}
          <div className="w-1/3 flex justify-center items-center">
            <img
              src="/images/sa.png"
              alt="Activity Hub"
              className="w-full h-auto object-cover rounded-lg"
            />
          </div>

          {/* Text Section */}
          <div className="w-2/3 pl-8">
            <h2 className="text-3xl font-bold text-white text-center mb-6">
              About Activity Hub
            </h2>
            <p className="text-lg leading-relaxed text-white/90">
              Activity Hub is your ultimate destination for managing
              extracurricular activities. Whether you're exploring clubs,
              organizing events, or showcasing achievements, this platform
              empowers you to excel. Here's why students love it:
            </p>
            <ul className="mt-6 space-y-4 list-disc list-inside text-white/80">
              <li>
                <strong>Join Clubs:</strong> Explore and connect with clubs that
                match your interests.
              </li>
              <li>
                <strong>Track Achievements:</strong> Build a portfolio of your
                milestones.
              </li>
              <li>
                <strong>Stay Informed:</strong> Get updates about events and
                activities on campus.
              </li>
              <li>
                <strong>Collaborate:</strong> Seamlessly work with teams on shared
                goals.
              </li>
            </ul>
          </div>
        </section>

        {/* Features Section */}
        <section className="space-y-16">
          <h2 className="text-3xl font-bold text-center text-white">
            What Makes Activity Hub Unique
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Feature 1 */}
            <div className="bg-white/10 backdrop-blur-md text-gray-200 p-6 rounded-lg shadow-lg hover:shadow-xl transition">
              <h3 className="text-xl font-semibold mb-2">
                Personalized Dashboard
              </h3>
              <p>
                Access a personalized dashboard to view all your activities at a
                glance.
              </p>
            </div>
            {/* Feature 2 */}
            <div className="bg-white/10 backdrop-blur-md text-gray-200 p-6 rounded-lg shadow-lg hover:shadow-xl transition">
              <h3 className="text-xl font-semibold mb-2">Event Management</h3>
              <p>Plan, organize, and participate in events with ease.</p>
            </div>
            {/* Feature 3 */}
            <div className="bg-white/10 backdrop-blur-md text-gray-200 p-6 rounded-lg shadow-lg hover:shadow-xl transition">
              <h3 className="text-xl font-semibold mb-2">
                Achievements Showcase
              </h3>
              <p>Build a digital portfolio of your accomplishments.</p>
            </div>
            {/* Feature 4 */}
            <div className="bg-white/10 backdrop-blur-md text-gray-200 p-6 rounded-lg shadow-lg hover:shadow-xl transition">
              <h3 className="text-xl font-semibold mb-2">Club Discovery</h3>
              <p>Find and join clubs that align with your interests and skills.</p>
            </div>
            {/* Feature 5 */}
            <div className="bg-white/10 backdrop-blur-md text-gray-200 p-6 rounded-lg shadow-lg hover:shadow-xl transition">
              <h3 className="text-xl font-semibold mb-2">Team Collaboration</h3>
              <p>
                Work together seamlessly with other members on shared projects
                and goals.
              </p>
            </div>
            {/* Feature 6 */}
            <div className="bg-white/10 backdrop-blur-md text-gray-200 p-6 rounded-lg shadow-lg hover:shadow-xl transition">
              <h3 className="text-xl font-semibold mb-2">Campus Updates</h3>
              <p>
                Stay updated with the latest campus events, news, and
                announcements.
              </p>
            </div>
          </div>
        </section>
        <PencilLine />


        {/* FAQ Section */}
        <section className="flex items-center justify-center space-x-6 bg-gradient-to-r from-white/20 to-white/10 backdrop-blur-lg rounded-lg p-10 shadow-lg h-screen">
          <div className="w-full md:w-1/2 text-left text-white">
            <h2 className="text-3xl font-bold mb-6">Frequently Asked Questions(FAQs)</h2>
            <div className="space-y-6 text-left">
              <div>
                <h3 className="font-semibold text-lg">
                  <span className="inline-block w-4 h-4 mr-2 bg-white rounded-full"></span>
                  Is Activity Hub free to use?
                </h3>
                <p className="text-white/80">
                  Yes, Activity Hub is free for all students.
                </p>
              </div>
              <div>
                <h3 className="font-semibold text-lg">
                  <span className="inline-block w-4 h-4 mr-2 bg-white rounded-full"></span>
                  How do I join a club or activity?
                </h3>
                <p className="text-white/80">
                  Simply explore the clubs on the platform and send a request
                  to join.
                </p>
              </div>
              <div>
                <h3 className="font-semibold text-lg">
                  <span className="inline-block w-4 h-4 mr-2 bg-white rounded-full"></span>
                  Can I showcase my achievements outside the campus?
                </h3>
                <p className="text-white/80">
                  Absolutely! You can add any achievements to your profile.
                </p>
              </div>
              <div>
                <h3 className="font-semibold text-lg">
                  <span className="inline-block w-4 h-4 mr-2 bg-white rounded-full"></span>
                  What kind of events can I participate in?
                </h3>
                <p className="text-white/80">
                  You can participate in various campus events, from academic
                  to extracurricular activities.
                </p>
              </div>
            </div>
          </div>

          <div
            className="w-full md:w-1/2 bg-cover bg-center rounded-lg"
            style={{
              backgroundImage: "url('/images/grp.jpg')",
              height: "400px",
            }}
          ></div>
        </section>

        {/* What Students Feel Section */}
        <section className="bg-white/10 backdrop-blur-md text-center p-16 space-y-8">
          <h2 className="text-3xl font-bold text-white">What Students Feel</h2>
          <div className="space-y-4 text-white/80">
            <p>"This platform helps me stay organized and manage all my activities in one place."</p>
            <p>"It's so easy to connect with clubs and events that match my interests."</p>
            <p>"I love how I can showcase my achievements and build my digital portfolio effortlessly."</p>
            <p>"The website keeps me updated with all the campus activities and announcements."</p>
          </div>
        </section>

        


        <PencilLine />



        

      {/* Ready to Get Started Section */}
      <section className="bg-white/10 backdrop-blur-md text-center p-16 space-y-8">
  <h2 className="text-3xl font-bold text-white">Ready to Get Started?</h2>
  <p className="text-lg text-white/80">
    Join thousands of students who are already making the most of their campus life with Activity Hub.
  </p>
  <Link to="/signup">
  <button className="bg-blue-500 text-white px-6 py-2 rounded-md font-semibold hover:bg-blue-600 transition duration-200">
    Sign Up Now
  </button>
  </Link>
</section>


      </main>

      {/* Footer */}
      <footer className="bg-indigo-700 text-white py-2 fixed bottom-0 w-full">
  <div className="container mx-auto text-center">
    <p className="text-sm leading-tight">&copy; 2024 Activity Hub. All rights reserved.</p>
  </div>
</footer>


{showButton && (
       <button
       onClick={scrollToTop}
       className="fixed bottom-20 right-10 bg-indigo-600 text-white w-16 h-16 p-4 rounded-full shadow-lg hover:bg-indigo-700 transition"
       aria-label="Scroll to top"
     >
       ↑
     </button>
      )}

    </div>
  );
};

export default Home;
