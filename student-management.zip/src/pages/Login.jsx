import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { useUserContext } from '../context/UserContext';  // Import the UserContext

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');
  
  const { setUser } = useUserContext();  // Access the setUser function from the UserContext
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      // Send POST request to your backend API
      const response = await axios.post('http://localhost:8080/api/login', {
        email,
        password,
      });
  
      // Handle the response from the backend
      if (response.data.success) {
        const { fullName, studentId, email, password } = response.data;
  
        // Clear any existing user data before setting the new user's data
        setUser(null);  // This will clear the global state first
  
        // Set the new user data globally using setUser
        setUser({ fullName, email, studentId, password });
  
        console.log("User data set globally:", { fullName, email, studentId, password });
  
        // Navigate to the dashboard directly without passing user data
        navigate('/dashboard');
  
        // Optional: If you need the data in AddAch, store it in localStorage
        localStorage.setItem('redirectToAddAch', true);
      } else {
        setMessage(response.data.message || 'Invalid email or password');
      }
    } catch (error) {
      // Handle login failure
      setMessage('An error occurred. Please try again.');
    }
  };
  
  return (
    <div
      className="flex items-center justify-center min-h-screen bg-cover bg-center"
      style={{ backgroundImage: "url('/images/bg.jpg')" }}
    >
      <div className="relative bg-gradient-to-r from-blue-500 to-indigo-600 p-8 rounded-lg shadow-xl max-w-sm w-full bg-opacity-50 backdrop-blur-sm">
        <h2 className="text-3xl font-bold text-center text-white mb-6">Login</h2>
        <form className="space-y-4" onSubmit={handleLogin}>
          <div>
            <label className="block text-white">Email</label>
            <input
              type="email"
              className="w-full border border-gray-300 rounded-md p-3 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <div>
            <label className="block text-white">Password</label>
            <input
              type="password"
              className="w-full border border-gray-300 rounded-md p-3 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              placeholder="Enter your password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          <button
            type="submit"
            className="w-full bg-indigo-600 text-white px-6 py-3 rounded-md hover:bg-indigo-700 transition"
          >
            Login
          </button>
        </form>

        {message && <div className="text-center text-white mt-4">{message}</div>}

        <div className="text-center mt-4">
          Forgot your password?
        </div>
        <div className="text-center mt-6">
          <span className="text-white text-sm">
            New user?{' '}
            <Link to="/signup" className="text-indigo-200 hover:text-indigo-300 underline">
              Click here to Sign Up
            </Link>
          </span>
        </div>
      </div>
    </div>
  );
};

export default Login;
