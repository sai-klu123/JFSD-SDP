import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const Signup = () => {
  const [formData, setFormData] = useState({
    studentId: '',
    fullName: '',
    email: '',
    password: '',
  });

  const [isLoginMode, setIsLoginMode] = useState(false);
  const navigate = useNavigate(); // Initialize navigate

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const endpoint = isLoginMode
        ? 'http://localhost:8080/api/login'
        : 'http://localhost:8080/api/signup';

      const response = await axios.post(endpoint, formData);

      alert(response.data.message || (isLoginMode ? 'Login successful' : 'Signup successful'));

      // Redirect to login page after successful signup or login
      if (!isLoginMode) {
        navigate('/login');
      }
    } catch (error) {
      console.error('Error:', error.response?.data?.message || error.message);
      alert(isLoginMode ? 'Login failed' : 'Registration failed');
    }
  };

  return (
    <div
      className="flex items-center justify-center min-h-screen bg-cover bg-center"
      style={{ backgroundImage: "url('/images/bg.jpg')" }}
    >
      <div className="relative bg-gradient-to-r from-blue-500 to-indigo-600 p-8 rounded-lg shadow-xl max-w-sm w-full bg-opacity-50 backdrop-blur-sm">
        <h2 className="text-3xl font-bold text-center text-white mb-6">
          {isLoginMode ? 'Login' : 'Sign Up'}
        </h2>
        <form className="space-y-4" onSubmit={handleSubmit}>
          {!isLoginMode && (
            <>
              <div>
                <label className="block text-white">Student ID</label>
                <input
                  type="text"
                  name="studentId"
                  className="w-full border border-gray-300 rounded-md p-3 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  placeholder="Enter your student ID"
                  value={formData.studentId}
                  onChange={handleChange}
                />
              </div>
              <div>
                <label className="block text-white">Full Name</label>
                <input
                  type="text"
                  name="fullName"
                  className="w-full border border-gray-300 rounded-md p-3 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  placeholder="Enter your full name"
                  value={formData.fullName}
                  onChange={handleChange}
                />
              </div>
            </>
          )}
          <div>
            <label className="block text-white">Email</label>
            <input
              type="email"
              name="email"
              className="w-full border border-gray-300 rounded-md p-3 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              placeholder="Enter your email"
              value={formData.email}
              onChange={handleChange}
            />
          </div>
          <div>
            <label className="block text-white">Password</label>
            <input
              type="password"
              name="password"
              className="w-full border border-gray-300 rounded-md p-3 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              placeholder="Enter your password"
              value={formData.password}
              onChange={handleChange}
            />
          </div>

          <button
            type="submit"
            className="w-full bg-indigo-600 text-white px-6 py-3 rounded-md hover:bg-indigo-700 transition"
          >
            {isLoginMode ? 'Login' : 'Sign Up'}
          </button>
        </form>
        <p className="text-white mt-4 text-center">
          {isLoginMode
            ? "Don't have an account? "
            : 'Already have an account? '}
          <span
            className="underline cursor-pointer text-indigo-300 hover:text-indigo-400"
            onClick={() => {
              setIsLoginMode(!isLoginMode);
              navigate('/login'); // Navigate to login page when switching
            }}
          >
            {isLoginMode ? 'Sign Up' : 'Login'}
          </span>
        </p>
      </div>
    </div>
  );
};

export default Signup;
