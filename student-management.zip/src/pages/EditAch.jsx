import React, { useEffect, useState } from "react";
import { useUserContext } from "../context/UserContext"; // Ensure correct import path
import { useNavigate } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faArrowLeft, faEdit } from "@fortawesome/free-solid-svg-icons";

const EditAch = () => {
  const { user, setUser } = useUserContext(); // Use setUser from UserContext
  const [achievements, setAchievements] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [editingAchievement, setEditingAchievement] = useState(null);
  const [showEditPopup, setShowEditPopup] = useState(false);
  const navigate = useNavigate();

  const countAchievements = () => {
    const total = achievements.length;
    const accepted = achievements.filter((ach) => ach.flag === 1).length;
    const rejected = achievements.filter((ach) => ach.flag === -1).length;
    const pending = achievements.filter((ach) => ach.flag === 0).length;

    return { total, accepted, rejected, pending };
  };

  useEffect(() => {
    if (!user) {
      const savedUser = localStorage.getItem("user");
      if (savedUser) {
        const parsedUser = JSON.parse(savedUser);
        setUser(parsedUser); // Correctly using setUser
      } else {
        setError("User not logged in.");
        setLoading(false);
        return;
      }
    }

    const fetchAchievements = async () => {
      try {
        const response = await fetch(
          `http://localhost:8080/api/achievements/${user.studentId}`
        );
        if (!response.ok) {
          throw new Error("Failed to fetch achievements");
        }
        const data = await response.json();
        setAchievements(data);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchAchievements();
  }, [user, setUser]);

  const handleEditClick = (achievement) => {
    setEditingAchievement({ ...achievement });
    setShowEditPopup(true);
  };

  const handleSaveEdit = async () => {
    if (!editingAchievement) return;

    try {
      const response = await fetch(
        `http://localhost:8080/api/achievements/${editingAchievement.id}`,
        {
          method: "PATCH",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(editingAchievement),
        }
      );

      if (!response.ok) {
        throw new Error("Failed to save changes.");
      }

      const updatedAchievement = await response.json();
      setAchievements((prev) =>
        prev.map((ach) =>
          ach.id === updatedAchievement.id ? updatedAchievement : ach
        )
      );
      setShowEditPopup(false); // Close the popup after saving
      setEditingAchievement(null);
    } catch (err) {
      setError(err.message);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setEditingAchievement((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  if (loading) {
    return <div className="text-white text-center mt-10">Loading achievements...</div>;
  }

  if (error) {
    return <div className="text-red-500 text-center mt-10">Error: {error}</div>;
  }

  const { total, accepted, rejected, pending } = countAchievements();

  return (
    <div className="bg-gradient-to-br from-blue-800 via-indigo-500 to-purple-600 min-h-screen flex flex-col">
      <div className="container mx-auto p-6">
        <header className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold">{user?.fullName}'s Achievements</h1>
          <button
            onClick={() => navigate("/dashboard")}
            className="flex items-center px-6 py-3 bg-blue-600 text-white rounded-lg shadow-lg hover:bg-blue-700 transition"
          >
            <FontAwesomeIcon icon={faArrowLeft} className="mr-2" />
            Back to Dashboard
          </button>
        </header>

        {/* Achievement Summary */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-8">
          <div className="p-6 bg-white text-black rounded-lg shadow-md text-center">
            <h3 className="font-semibold text-xl">Total Achievements</h3>
            <p className="text-3xl font-bold">{total}</p>
          </div>
          <div className="p-6 bg-green-500 text-white rounded-lg shadow-md text-center">
            <h3 className="font-semibold text-xl">Accepted</h3>
            <p className="text-3xl font-bold">{accepted}</p>
          </div>
          <div className="p-6 bg-red-500 text-white rounded-lg shadow-md text-center">
            <h3 className="font-semibold text-xl">Rejected</h3>
            <p className="text-3xl font-bold">{rejected}</p>
          </div>
          <div className="p-6 bg-blue-500 text-white rounded-lg shadow-md text-center">
            <h3 className="font-semibold text-xl">Pending</h3>
            <p className="text-3xl font-bold">{pending}</p>
          </div>
        </div>

        {/* Displaying Pending Achievements (flag === 0) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {achievements
            .filter((ach) => ach.flag === 0) // Only display pending achievements
            .map((achievement) => (
              <div
                key={achievement.id}
                className="bg-lightBlue-400 p-4 rounded-lg shadow-lg text-darkBlue-700 flex justify-between items-center"
              >
                <h2 className="text-xl font-bold">{achievement.title}</h2>
                <button
                  onClick={() => handleEditClick(achievement)}
                  className="text-white bg-blue-500 px-4 py-2 rounded-lg"
                >
                  <FontAwesomeIcon icon={faEdit} />
                </button>
              </div>
            ))}
        </div>
      </div>

      {/* Edit Achievement Popup */}
{showEditPopup && editingAchievement && (
  <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center">
    <div className="relative bg-gradient-to-r from-blue-500 to-indigo-600 p-8 rounded-lg shadow-xl max-w-3xl w-full bg-opacity-90 backdrop-blur-sm overflow-y-auto max-h-[80vh]">
      {/* Close Button */}
      <button
        onClick={() => setShowEditPopup(false)} // Close the popup when clicked
        className="absolute top-4 right-4 text-white text-2xl bg-transparent hover:text-gray-400 focus:outline-none"
      >
        &times;
      </button>

      <div className="text-black mb-6 text-center">
        <p className="font-bold">Editing Achievement</p>
        <p className="font-extrabold">{editingAchievement.title}</p>
      </div>

      <form className="space-y-4" onSubmit={handleSaveEdit}>
  <div>
    <label className="block text-black">Achievement Title</label>
    <input
      type="text"
      name="title"
      className="w-full border border-gray-300 rounded-md p-3 focus:outline-none focus:ring-2 focus:ring-indigo-500"
      placeholder="Enter achievement title"
      value={editingAchievement?.title || ""} // Fallback to empty string if null or undefined
      onChange={handleChange}
      required
    />
  </div>

  <div>
    <label className="block text-black">Description</label>
    <textarea
      name="description"
      className="w-full border border-gray-300 rounded-md p-3 focus:outline-none focus:ring-2 focus:ring-indigo-500"
      placeholder="Enter achievement description"
      value={editingAchievement?.description || ""} // Fallback to empty string if null or undefined
      onChange={handleChange}
      required
    />
  </div>

  <div>
    <label className="block text-black">Year</label>
    <input
      type="text"
      name="year"
      className="w-full border border-gray-300 rounded-md p-3 focus:outline-none focus:ring-2 focus:ring-indigo-500"
      placeholder="Enter year of achievement"
      value={editingAchievement?.year || ""} // Fallback to empty string if null or undefined
      onChange={handleChange}
      required
    />
  </div>

  <div>
    <label className="block text-black">Company</label>
    <input
      type="text"
      name="company"
      className="w-full border border-gray-300 rounded-md p-3 focus:outline-none focus:ring-2 focus:ring-indigo-500"
      placeholder="Enter the company name"
      value={editingAchievement?.company || ""} // Fallback to empty string if null or undefined
      onChange={handleChange}
      required
    />
  </div>

  <div>
    <label className="block text-black">Prize Money (if any)</label>
    <input
      type="number"
      name="priceMoney"
      className="w-full border border-gray-300 rounded-md p-3 focus:outline-none focus:ring-2 focus:ring-indigo-500"
      placeholder="Enter prize money"
      value={editingAchievement?.priceMoney || ""} // Fallback to empty string if null or undefined
      onChange={handleChange}
    />
  </div>

  <div>
    <label className="block text-black">Achievement Proof</label>
    <input
      type="text"
      name="achievementProof"
      className="w-full border border-gray-300 rounded-md p-3 focus:outline-none focus:ring-2 focus:ring-indigo-500"
      placeholder="Enter proof link or description"
      value={editingAchievement?.achievementProof || ""} // Fallback to empty string if null or undefined
      onChange={handleChange}
    />
    <p className="text-black text-sm mt-1">
      *If you want to submit it offline, submit it before 24hrs on Cabin number C205.
    </p>
  </div>

  <button
    type="submit"
    className="w-full bg-indigo-600 text-white px-6 py-3 rounded-md hover:bg-indigo-700 transition"
  >
    Save Changes
  </button>
</form>

    </div>
  </div>
)}

    </div>
  );
};

export default EditAch;
