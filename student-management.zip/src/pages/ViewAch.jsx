import React, { useEffect, useState } from 'react';
import { useUserContext } from '../context/UserContext';
import { useNavigate } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faArrowLeft } from '@fortawesome/free-solid-svg-icons';

const ViewAch = () => {
  const { user, setUser } = useUserContext(); // Access user from context
  const [achievements, setAchievements] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [hoveredAchievement, setHoveredAchievement] = useState(null); // Track hovered achievement
  const navigate = useNavigate();

  const countAchievements = () => {
    let total = achievements.length;
    let accepted = achievements.filter(ach => ach.flag === 1).length;
    let rejected = achievements.filter(ach => ach.flag === -1).length;
    let pending = achievements.filter(ach => ach.flag === 0).length;

    return { total, accepted, rejected, pending };
  };

  useEffect(() => {
    // Check for user in context, otherwise check localStorage
    const checkUser = () => {
      if (!user) {
        const savedUser = localStorage.getItem('user');
        if (savedUser) {
          const parsedUser = JSON.parse(savedUser);
          setUser(parsedUser); // Set user from localStorage in context
        } else {
          navigate('/login'); // Redirect to login if no user found
        }
      }
    };

    checkUser();
  }, [user, setUser, navigate]);

  useEffect(() => {
    if (user && user.studentId) {
      // Only fetch achievements if user is logged in
      const fetchAchievements = async () => {
        try {
          setLoading(true); // Set loading true before fetching
          const response = await fetch(
            `http://localhost:8080/api/achievements/${user.studentId}`
          );
          if (!response.ok) {
            throw new Error('Failed to fetch achievements');
          }
          const data = await response.json();
          setAchievements(data);
        } catch (err) {
          setError(err.message);
        } finally {
          setLoading(false); // Set loading to false after fetch completes
        }
      };

      fetchAchievements();
    }
  }, [user]); // Fetch achievements only when user changes

  // Display loading state until achievements are fetched
  if (loading) {
    return <div>Loading achievements...</div>;
  }

  if (error) {
    return <div>Error: {error}</div>;
  }

  const { total, accepted, rejected, pending } = countAchievements();

  return (
    <div className="bg-gradient-to-br from-blue-800 via-indigo-500 to-purple-600 min-h-screen flex flex-col">
      <div className="absolute inset-0 bg-black opacity-50"></div> {/* Background overlay */}
      <div className="container mx-auto text-white relative p-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold">{user.fullName}'s Achievements</h1>
          <button
            onClick={() => navigate('/dashboard')}
            className="flex items-center px-6 py-3 bg-blue-600 text-white rounded-lg shadow-lg hover:bg-blue-700 transition"
          >
            <FontAwesomeIcon icon={faArrowLeft} className="mr-2" />
            Back to Dashboard
          </button>
        </div>

        {/* Achievement Counts Section */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-6 mb-6">
          <div className="p-6 bg-gray-400 rounded-lg shadow-lg text-center">
            <h3 className="font-semibold text-xl text-black">Total Achievements</h3>
            <p className="text-3xl font-bold text-black">{total}</p>
          </div>

          <div className="p-6 bg-green-400 rounded-lg shadow-lg text-center">
            <h3 className="font-semibold text-xl text-black">Accepted</h3>
            <p className="text-3xl font-bold text-black">{accepted}</p>
          </div>
          <div className="p-6 bg-red-400 rounded-lg shadow-lg text-center">
            <h3 className="font-semibold text-xl text-black">Rejected</h3>
            <p className="text-3xl font-bold text-black">{rejected}</p>
          </div>
          <div className="p-6 bg-blue-400 rounded-lg shadow-lg text-center">
            <h3 className="font-semibold text-xl text-black">Pending</h3>
            <p className="text-3xl font-bold text-black">{pending}</p>
          </div>
        </div>

        {/* Achievement Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {achievements.map((achievement) => (
            <div
              key={achievement.id}
              className={`relative p-6 rounded-lg shadow-lg transition-all transform ${
                achievement.flag === 1
                  ? 'bg-green-400' // No bulging effect for green (Accepted)
                  : achievement.flag === -1
                  ? 'bg-red-400' // No bulging effect for red (Rejected)
                  : 'bg-blue-400' // No bulging effect for blue (Pending)
              }`}
              onMouseEnter={() => setHoveredAchievement(achievement.id)}
              onMouseLeave={() => setHoveredAchievement(null)}
            >
              <h2 className="text-xl font-bold text-black text-center">{achievement.title}</h2>
              <p className="text-black text-center"><strong>Description:</strong> {achievement.description || 'No description available'}</p>
              <p className="text-black text-center"><strong>Year:</strong> {achievement.year || 'N/A'}</p>
              {achievement.company && <p className="text-black text-center"><strong>Company:</strong> {achievement.company}</p>}
              {achievement.priceMoney && <p className="text-black text-center"><strong>Prize Money:</strong> ${achievement.priceMoney}</p>}
              <p className="text-black text-center"><strong>Status:</strong> {achievement.flag === 1 ? 'Accepted' : achievement.flag === -1 ? 'Rejected' : 'Pending'}</p>

              {/* Blur and Overlay Effect for Message */}
              <div
                className={`absolute inset-0 flex justify-center items-center text-white text-xl font-bold ${
                  achievement.flag === 1 && hoveredAchievement === achievement.id
                    ? 'bg-black bg-opacity-50 backdrop-blur-sm'
                    : ''
                } ${achievement.flag === -1 && hoveredAchievement === achievement.id
                  ? 'bg-black bg-opacity-50 backdrop-blur-sm'
                  : ''
                } ${achievement.flag === 0 && hoveredAchievement === achievement.id
                  ? 'bg-black bg-opacity-50 backdrop-blur-sm'
                  : ''
                }`}
              >
                {achievement.flag === 1 && hoveredAchievement === achievement.id && (
                  <p>Accepted</p>
                )}
                {achievement.flag === -1 && hoveredAchievement === achievement.id && (
                  <p>Rejected due to insufficient proof</p>
                )}
                {achievement.flag === 0 && hoveredAchievement === achievement.id && (
                  <p>Submitted for grading</p>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ViewAch;
