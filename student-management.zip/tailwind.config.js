module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"], // Ensure this includes your file paths
  theme: {
    extend: {},
  },
  plugins: [],
};
